package com.capgemini.onlinewallet.exe;

import java.util.HashMap;
import java.util.Scanner;

import com.capgemini.onlinewallet.dto.WalletAccount;
import com.capgemini.onlinewallet.dto.WalletUser;
import com.capgemini.onlinewallet.service.CreateWallet;

public class MainClass {
	public static void main(String[] args) {
		
		HashMap<Integer,WalletUser> walletUserHM = new HashMap(); 
		HashMap<Integer,WalletAccount> walletAccountHM = new HashMap(); 
		
		int userId=0;
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Welcome");
		System.out.println("Press 1 for Login Press 2 for Signup");
		int c=sc.nextInt();
		switch(c) {
			case 2:
				
				userId+=1;
				System.out.println("Enter User Name");
				sc.nextLine();
				String userName=sc.nextLine();
				System.out.println("Enter Password");
				String password=sc.nextLine();
				System.out.println("Enter Phone Number");
				String phoneNumber=sc.nextLine();
				System.out.println("Enter Login Name");
				String loginName=sc.nextLine();
				CreateWallet cw = new CreateWallet();
				WalletUser wu = cw.register(userId,userName,password,phoneNumber,loginName); 
				walletUserHM.put(userId,wu);
				walletAccountHM.put(userId,cw.createWalletAccount(wu));
				System.out.println("------------------Account Created Successfully-------------");
				break;
			default:
				System.out.println("Sorry");
		}
		System.out.println(walletUserHM);
		System.out.println(walletAccountHM);
	}
}
//int userId, String userName, String password, String phoneNumber, String loginName
package com.capgemini.onlinewallet.service;

import java.util.*;

import com.capgemini.onlinewallet.dto.*;

public class DataStorage {
	
	static HashMap<Integer,WalletUser> walletUserStore = new HashMap<Integer,WalletUser>();
	static HashMap<Integer,WalletAccount> walletAccountStore = new HashMap<Integer,WalletAccount>();
	
	static void addUser(WalletUser wu) {
		
		if((walletUserStore.get(wu.getUserId()).getPhoneNumber()).equals(wu.getPhoneNumber())) {
			System.out.println("User Already Exists");
		}else {
			walletUserStore.put(wu.getUserId(),wu);
			walletAccountStore.put(wu.getUserId(),new WalletAccount(wu.getUserId(),0.0,true,null));
		}
		
	}
	
	
	
	
	public static HashMap<Integer, WalletUser> getWalletUserStore() {
		return walletUserStore;
	}
	
	
	

	public static HashMap<Integer, WalletAccount> getWalletAccountStore() {
		return walletAccountStore;
	}

	
	
	
	public static void setWalletUserStore(HashMap<Integer, WalletUser> walletUserStore) {
		DataStorage.walletUserStore = walletUserStore;
	}
	
	
	

	public static void setWalletAccountStore(HashMap<Integer, WalletAccount> walletAccountStore) {
		DataStorage.walletAccountStore = walletAccountStore;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

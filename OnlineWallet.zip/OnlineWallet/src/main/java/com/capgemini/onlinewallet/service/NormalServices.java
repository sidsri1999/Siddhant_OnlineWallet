package com.capgemini.onlinewallet.service;

import java.util.Scanner;

public class NormalServices {
	Scanner sc = new Scanner(System.in);
	public int startMenu() {
		System.out.println(" 1 for UserLogin ");
		System.out.println(" 2 for AdminLogin ");
		int choice=sc.nextInt();
		if(choice!=1 && choice!=2) {
			return 0;
		}else {
			return choice;
		}
	}
	public int startMenuUser() {
		System.out.println(" 1 for Login ");
		System.out.println(" 2 for Create Account");
		int choice=sc.nextInt();
		if(choice!=1 && choice!=2) {
			return 0;
		}else {
			return choice;
		}
	}

}

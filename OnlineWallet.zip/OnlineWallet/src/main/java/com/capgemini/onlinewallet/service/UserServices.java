package com.capgemini.onlinewallet.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.capgemini.onlinewallet.dto.*;

public class UserServices {
	
Scanner sc = new Scanner(System.in);
	
	public boolean createWallet() {
		HashMap<Integer,WalletAccount> was = DataStorage.getWalletAccountStore();
		HashMap<Integer,WalletUser> wus = DataStorage.getWalletUserStore();
		int size=was.size();
		int userId=size+1;
		
		
		System.out.println("Enter User Name :- ");
		String userName=sc.nextLine();
		if(!Validation.userNamePassValidation(userName)){
			System.out.println("Enter a valid username");
			userName=sc.nextLine();
			if(!Validation.userNamePassValidation(userName)) {
				System.out.println("Sorry Try Again After Sometime!");
				return false;
			}
					
		}
		System.out.print("Enter Password :- ");
		String password=sc.nextLine();
		if(!Validation.userNamePassValidation(password)){
			System.out.println("Enter a valid username");
			password=sc.nextLine();
			if(!Validation.userNamePassValidation(password)) {
				System.out.println("Sorry Try Again After Sometime!");
				return false;
			}
					
		}
		
		System.out.print("Enter Phone Number :- ");
		String phoneNumber=sc.nextLine();
		if(!Validation.phoneNumberValidation(phoneNumber)){
			System.out.println("Enter a valid username");
			phoneNumber=sc.nextLine();
			if(!Validation.userNamePassValidation(phoneNumber)) {
				System.out.println("Sorry Try Again After Sometime!");
				return false;
			}
					
		}
		
		
		System.out.print("Enter Login Name :- ");
		String loginName=sc.nextLine();
		if(!Validation.loginNameValidation(loginName)){
			System.out.println("Enter a valid username");
			loginName=sc.nextLine();
			if(!Validation.userNamePassValidation(loginName)) {
				System.out.println("Sorry Try Again After Sometime!");
				return false;
			}
					
		}
		
		WalletUser wu = new WalletUser(userId, userName, password, phoneNumber, loginName);
		WalletAccount wa = new WalletAccount(userId , 0.0, true, null);
		
		int i=size;
		while(i>0) {
			if(wus.get(i).getPhoneNumber().equals(phoneNumber)) {
				System.out.println("There is another account linked with this phone number!\n\t Sorry");
				return false;
			}
		}
		wus.put(userId,wu);
		was.put(userId,wa);
		DataStorage.setWalletUserStore(wus);
		DataStorage.setWalletAccountStore(was);	
		System.out.println("Account Created Successfully!");
		return true;
	}
	
	
	
	
	public boolean AddAmount(int userId) {
		HashMap<Integer,WalletAccount> was = DataStorage.getWalletAccountStore();
		String description="Credit";
		System.out.print("Enter the money to added :- ");
		Double amount=sc.nextDouble();
		if(amount < 1.0) {
			System.out.println("Invalid Input!");
			return false;
		}else if(amount > 10000) {
			System.out.println("Amount should be less than 10000!");
			return false;
		}else {
			WalletAccount wa = was.get(userId);
			wa.setAccountBalance(wa.getAccountBalance()+amount);
			wa=transactionUpdate(description, amount, wa);
			was.put(userId,wa);
			return true;
		}
	}
	
	
	
	
	
	public boolean showBalance(int userId) {
		HashMap<Integer,WalletAccount> was = DataStorage.getWalletAccountStore();
		System.out.println(was.get(userId).getAccountId()+ " Having Balance: "+was.get(userId).getAccountBalance() );
		return true;
	}
	
	
	
	
	public boolean transferMoney(int AccountId1,int AccountId2) {
		String description1="Credited";
		String description2="Debited";
		HashMap<Integer,WalletAccount> was = DataStorage.getWalletAccountStore();
		if(was.containsKey(AccountId2)) {
			System.out.println("Enter the money to be transferred :- ");
			Double amount=sc.nextDouble();
			WalletAccount sender=was.get(AccountId1);
			WalletAccount reciever=was.get(AccountId2);
			if(amount<1.0) {
				System.out.println("Invalid Amount!");
				return false;
			}
			else if(amount>sender.getAccountBalance()) {
				System.out.println("Insufficient Funds!");
				return false;
			}else{
				sender.setAccountBalance(sender.getAccountBalance()-amount);
				reciever.setAccountBalance(reciever.getAccountBalance()+amount);
				sender=transactionUpdate(description1, amount, sender);
				reciever=transactionUpdate(description1, amount, reciever);
				was.put(sender.getAccountId(), sender);
				was.put(reciever.getAccountId(), reciever);
				DataStorage.setWalletAccountStore(was);
				System.out.println("Amount Successfully Added");
				System.out.println("Money Left"+(sender.getAccountBalance()-amount));
				return true;
			}
		}else {
			System.out.println("Invalid Reciever Id");
			return false;
		}
	}
	
	
	
	
	
	
	public WalletAccount transactionUpdate(String description,Double amount,WalletAccount wa) {
		List transactionH = wa.getTransactionHistory();
		int tid = transactionH.size()+1;
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");  
        String current = now.format(format);
		WalletTransactions wt = new WalletTransactions(tid,description,current,amount,wa.getAccountBalance());
		transactionH.add(wt);
		wa.setTransactionHistory(transactionH);
		return wa;
	}
	
	
	

}

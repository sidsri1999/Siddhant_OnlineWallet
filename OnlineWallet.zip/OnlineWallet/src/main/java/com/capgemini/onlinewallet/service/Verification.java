package com.capgemini.onlinewallet.service;

import java.util.*;

import com.capgemini.onlinewallet.dto.WalletUser;

public class Verification {
	
	
	Scanner sc = new Scanner(System.in);
	
	
	
	public boolean login(int userId,String password) {
		HashMap<Integer,WalletUser> wu = DataStorage.getWalletUserStore();
		if(wu.containsKey(userId) && wu.get(userId).getPassword().equals(password)) {
			System.out.println("Successfull Login");
			return true;
		}else {
			System.out.println("Invalid Credentials!");return false;
		}
	}
		
	
	
	
	
	public boolean checkUserExists(int userId) {
		HashMap<Integer,WalletUser> wu = DataStorage.getWalletUserStore();
		if(wu.containsKey(userId)) {
			return true;
		}
		return false;
	}
	
	
	
	
	public boolean forgotPassword() {
		System.out.print("Enter UserId :- ");
		int userId=sc.nextInt();
		sc.hasNextLine();
		System.out.print("Enter User Name :- ");
		String userName=sc.nextLine();
		System.out.print("Enter Phone Number :- ");
		String phoneNumber=sc.nextLine();
		HashMap<Integer,WalletUser> wu = DataStorage.getWalletUserStore();
		if(wu.containsKey(userId) && wu.get(userId).getUserName().equals(userName) && wu.get(userId).getPhoneNumber().equals(phoneNumber)) {
			WalletUser w = wu.get(userId);
			System.out.print("Enter New Password :- ");
			String password=sc.nextLine();
			w.setPassword(password);
			wu.put(userId,w);
			DataStorage.setWalletUserStore(wu);
			return true;
		}else {
			System.out.println("Invalid Credentials!");
			return false;
		}
		
	}
	
	
	
	
	
	
	

}
